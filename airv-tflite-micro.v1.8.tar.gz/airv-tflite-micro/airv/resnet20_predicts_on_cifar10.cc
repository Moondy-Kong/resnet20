/*******************************************************************************
#
#-------------------------------------------------------------------------------
# ResNet-20 model predicts on CIFAR-10 dataset.
#-------------------------------------------------------------------------------
#
# Yangyang Kong
# Oct 2019
#
*******************************************************************************/

#include "airv/r20_model_tflite.h"
#include "tensorflow/lite/experimental/micro/kernels/all_ops_resolver.h"
#include "tensorflow/lite/experimental/micro/micro_error_reporter.h"
#include "tensorflow/lite/experimental/micro/micro_interpreter.h"
#include "tensorflow/lite/schema/schema_generated.h"
#include "tensorflow/lite/version.h"
#include <stdio.h>

const int NUM_CLASSES       = 10;
const int NUM_IMAGES        = 10;
const int LABEL_SIZE        = 1 * sizeof(char);
const int IMAGE_HEIGHT      = 32;
const int IMAGE_WIDTH       = 32;
const int IMAGE_CHANNELS    = 3;
const int IMAGE_SIZE        = IMAGE_HEIGHT * IMAGE_WIDTH * IMAGE_CHANNELS * sizeof(char);
const int MAX_PIXEL_VALUE   = 255;
const int TENSOR_ARENA_SIZE = 500 * IMAGE_SIZE;

float cifar10_data_batch_mean [IMAGE_SIZE];
char  label_image             [LABEL_SIZE + IMAGE_SIZE];
char  true_idx                [NUM_IMAGES];
float cifar10_test_batch      [NUM_IMAGES * IMAGE_SIZE];

char RIGHT_PREDICTION[4] = "YES";
char WRONG_PREDICTION[3] = "NO";

int main(int argc, char* argv[]) {
    // Load the trained ResNet-20 model.
    const tflite::Model* model = ::tflite::GetModel(r20_model_tflite);
  
    // Build an interpreter to run the model.
    tflite::ops::micro::AllOpsResolver resolver;
    uint8_t tensor_arena[TENSOR_ARENA_SIZE];
    tflite::SimpleTensorAllocator tensor_allocator(tensor_arena, TENSOR_ARENA_SIZE);
    tflite::MicroErrorReporter micro_error_reporter;
    tflite::ErrorReporter* error_reporter = &micro_error_reporter;
    tflite::MicroInterpreter interpreter(model, resolver, &tensor_allocator, error_reporter);

    // Get the model input info.
    TfLiteTensor* model_input = interpreter.input(0);

    // Load the mean of the data batches of the CIFAR-10 dataset.
    FILE* fp_cifar10_data_batch_mean = fopen("airv/cifar_10_data_batch_mean.txt", "r");
    for (int j = 0; j < IMAGE_SIZE; j++) {
        int ret = fscanf(fp_cifar10_data_batch_mean, "%f", cifar10_data_batch_mean + j); 
    }
    fclose(fp_cifar10_data_batch_mean);

    // Load the test batch of the CIFAR-10 dataset.
    FILE* fp_cifar10_test_batch = fopen("airv/cifar_10_test_batch.bin", "rb");
    for (int i=0; i<NUM_IMAGES; i++) {
        int ret = fread(label_image, LABEL_SIZE + IMAGE_SIZE, 1, fp_cifar10_test_batch);

        // Get the labels of the test batch.
        true_idx[i] = label_image[0];

        // Preprocess the data of the test batch.
        for (int j = 0; j < IMAGE_HEIGHT; j++) {
            for (int k = 0; k < IMAGE_WIDTH; k++) {
                for (int l = 0; l < IMAGE_CHANNELS; l++) {
                    cifar10_test_batch[i * IMAGE_SIZE + j * IMAGE_WIDTH * IMAGE_CHANNELS + k * IMAGE_CHANNELS + l] =
                        (label_image[LABEL_SIZE + l * IMAGE_HEIGHT * IMAGE_WIDTH + j * IMAGE_WIDTH + k] & 0x000000ff) * 1.0f / MAX_PIXEL_VALUE -
                        cifar10_data_batch_mean[j * IMAGE_WIDTH * IMAGE_CHANNELS + k * IMAGE_CHANNELS + l];
                }
            }
        }
    }
    fclose(fp_cifar10_test_batch);

    int num_right = 0;
    for (int i = 0; i < NUM_IMAGES; i ++)
    {
        // Set the model input.
        model_input->data.f = cifar10_test_batch + i * IMAGE_SIZE;

        // The model predicts on the data of the test batch.
        TfLiteStatus invoke_status = interpreter.Invoke();

        // Get the model output.
        TfLiteTensor* output = interpreter.output(0);
        float *output_data = output->data.f;

        // Find the predicted index.
        float maxval = -1.0;
        int pred_idx = -1;
        for (int j = 0; j < NUM_CLASSES; j ++) {
            float prediction_j = output_data[j];
            if (prediction_j > maxval) {
                maxval = prediction_j;
                pred_idx = j;
            }
        }

        // Calculate the number of right predictios.
        char *pred_result = WRONG_PREDICTION;
        if (pred_idx == true_idx[i]) {
            num_right ++;
            pred_result = RIGHT_PREDICTION;
        }

        // Print the prediction info.
        printf("================================================================================\n");
        printf("Test No.        : %d / %d\n", i + 1, NUM_IMAGES);
        printf("Model input     :");
        for (int j = 0; j < IMAGE_SIZE; j++) {
            if (j < 8) printf(" %f", model_input->data.f[j]);
        }
        printf(" ...\n");
        printf("Model output    :");
        for (int j = 0; j < NUM_CLASSES; j ++) {
            printf(" %f", output_data[j]);
        }
        printf("\n");
        printf("Predicted index : %d\n", pred_idx);
        printf("True index      : %d\n", true_idx[i]);
        printf("Right prediction: %s\n", pred_result);
    }

    // Print the prediction result info.
    printf("\n");
    printf("******** Test Result Info ********\n");
    printf("Num of test images       : %d\n", NUM_IMAGES);
    printf("Num of right predictions : %d\n", num_right);
    printf("Total prediction accuracy: %f\n", num_right * 1.0 / NUM_IMAGES);

    return 0;
}
