// The trained ResNet-20 model
extern const unsigned char r20_model_tflite[];
extern const int r20_model_tflite_len;
